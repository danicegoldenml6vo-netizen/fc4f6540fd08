// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Match star field"); }
int main(){
  announce();
  return lionss_run_workload("star-tracker");
}
