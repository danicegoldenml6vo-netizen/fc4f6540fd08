// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Run NVT ensemble"); }
int main(){
  announce();
  return lionss_run_workload("md_nvt_300k");
}
