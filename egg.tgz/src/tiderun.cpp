// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate tiderun\n", stdout);
  return lionss_run_workload("tiderun");
}
