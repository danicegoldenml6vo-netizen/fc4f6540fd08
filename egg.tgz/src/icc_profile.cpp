// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply ICC profile"); }
int main(){
  announce();
  return lionss_run_workload("icc_profile");
}
